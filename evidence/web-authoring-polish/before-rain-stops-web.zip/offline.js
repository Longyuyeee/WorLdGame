(() => {
  const panel = document.getElementById('offline-panel');
  const version = document.getElementById('world-publication-version');
  const layout = () => document.body.style.setProperty('--player-viewport-offset', Math.ceil((panel?.getBoundingClientRect().height ?? 0) + (version?.getBoundingClientRect().height ?? 0)) + 'px');
  layout();
  panel?.addEventListener('toggle', layout);
  // details.toggle may be queued after its open attribute has already changed layout.
  // Rebudget in the mutation microtask so the first expanded frame stays readable.
  if (panel && typeof MutationObserver === 'function') new MutationObserver(layout).observe(panel, { attributes: true, attributeFilter: ['open'] });
  window.addEventListener('resize', layout);
  if (typeof ResizeObserver === 'function') {
    const observer = new ResizeObserver(layout);
    if (panel) observer.observe(panel);
    if (version) observer.observe(version);
  }
  const status = document.getElementById('offline-status');
  const action = document.getElementById('offline-action');
  const install = document.getElementById('offline-install');
  let registration, promptEvent;
  const say = text => { status.textContent = text; };
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault(); promptEvent = event; install.hidden = false;
  });
  install.onclick = async () => {
    if (!promptEvent) return;
    await promptEvent.prompt(); await promptEvent.userChoice;
    promptEvent = undefined; install.hidden = true;
  };
  if (location.protocol === 'world-game:') {
    say('桌面播放器已使用本地游戏文件，无需下载网站离线内容。'); action.hidden = true; return;
  }
  if (location.protocol === 'file:') {
    say('本地目录可直接试玩；网站离线与安装需发布到 HTTPS 站点。'); action.hidden = true; return;
  }
  if (!isSecureContext || !('serviceWorker' in navigator)) {
    say('当前浏览器或网址不支持网站离线，可继续在线玩；请使用 HTTPS 或下载完整目录包。'); action.hidden = true; return;
  }
  const request = (worker, type) => new Promise((resolve, reject) => {
    const channel = new MessageChannel();
    const timer = setTimeout(() => { channel.port1.close(); reject(new Error('timeout')); }, type === 'CACHE' ? 300000 : 10000);
    channel.port1.onmessage = event => { clearTimeout(timer); channel.port1.close(); resolve(event.data); };
    worker.postMessage({ type }, [channel.port2]);
  });
  const waiting = () => {
    if (!registration?.waiting) return false;
    say('新版已下载。请先保存进度，关闭所有此游戏窗口后重新打开；不会自动打断剧情。');
    action.disabled = false; action.textContent = '检查更新'; return true;
  };
  const ready = async () => {
    if (waiting()) return;
    if (!registration?.active) return;
    try {
      const result = await request(registration.active, 'STATUS');
      if (waiting()) return;
      if (result.ready) { say('离线内容已就绪，可断网后重开此网址。浏览器清理站点数据后需重新下载。'); action.textContent = '检查更新'; }
      else { say('离线内容不完整，请联网重新下载；在线游玩仍可继续。'); action.textContent = '重试离线下载'; }
    } catch { say('暂时无法确认离线内容，请联网重试。'); action.textContent = '重试离线下载'; }
    action.disabled = false;
  };
  const observe = worker => {
    if (!worker) return;
    say('正在下载离线内容，请保持页面打开；你可以继续游玩。'); action.disabled = true;
    const changed = () => {
      if (worker.state === 'activated') void ready();
      if (worker.state === 'installed') { if (!waiting()) say('离线下载完成，正在准备…'); }
      if (worker.state === 'redundant') { say('离线下载失败，请检查网络和可用空间后重试；在线游戏仍可继续。'); action.disabled = false; action.textContent = '重试离线下载'; }
    };
    worker.addEventListener('statechange', changed); changed();
  };
  const watch = () => {
    registration.addEventListener('updatefound', () => observe(registration.installing));
    if (registration.installing) observe(registration.installing); else void ready();
  };
  action.onclick = async () => {
    action.disabled = true;
    try {
      if (!registration || (!registration.active && !registration.waiting && !registration.installing)) { registration = await navigator.serviceWorker.register('./sw.js', { scope: './', updateViaCache: 'none' }); watch(); }
      else if (action.textContent === '重试离线下载' && registration.active) {
        say('正在重新下载离线内容…');
        const result = await request(registration.active, 'CACHE');
        if (!result.ready) throw new Error('cache failed');
        await ready();
      } else {
        await registration.update();
        if (!registration.installing) await ready();
      }
    } catch { say('离线下载或更新失败，请检查网络和可用空间后重试；现有游戏可继续。'); action.disabled = false; action.textContent = '重试离线下载'; }
  };
  navigator.serviceWorker.getRegistration('./').then(value => {
    if (value && value.scope === new URL('./', location.href).href) { registration = value; watch(); }
  }).catch(() => { say('无法读取离线状态，请重试。'); });
})();