const inventory = {"optimization-report.json":"sha256:776026eed4e060bebe061534ebad4b856b88223343059edd48c36313f467b705","media/98047083a6a3c82c7d33277d59ea687c16b7cde56bedf198d899db652eff9f9b.woff2":"sha256:98047083a6a3c82c7d33277d59ea687c16b7cde56bedf198d899db652eff9f9b","media/6ef4b958c86328d5515b034a7060e5081430fcdc279536ceeaac43f15ce7f83b.png":"sha256:6ef4b958c86328d5515b034a7060e5081430fcdc279536ceeaac43f15ce7f83b","media/d69d2e28ca0d7d547c27f32cbd49703ebc40ddf36b0224f56001f7d2a73bd16a.wav":"sha256:d69d2e28ca0d7d547c27f32cbd49703ebc40ddf36b0224f56001f7d2a73bd16a","media/fbbc665d5ebb4e5dad123383d1077f3d968a620b7e36cce46795c08669605c98.wav":"sha256:fbbc665d5ebb4e5dad123383d1077f3d968a620b7e36cce46795c08669605c98","media/7b0aeee0aef6219584fef7833b6960ecb316bffa3b565ab13f847151068ba0bd.png":"sha256:7b0aeee0aef6219584fef7833b6960ecb316bffa3b565ab13f847151068ba0bd","media/9a2a3bce8a89205a0ae6ac1cd22620dedae77bd519db5ec5c90b2302b55db47b.png":"sha256:9a2a3bce8a89205a0ae6ac1cd22620dedae77bd519db5ec5c90b2302b55db47b","media/5ab4b3cf1b83bf897d386238f1fad4e87f36b6eea3d940e0c3d4101204404e37.png":"sha256:5ab4b3cf1b83bf897d386238f1fad4e87f36b6eea3d940e0c3d4101204404e37","index.html":"sha256:804b06e60980898d52553c0ca89d6faf5d824e5fc08b4017f71174100f6d3ac2","player.js":"sha256:312aa3eaac25bbe3443f0fda15aa29c19c3cd627f4fca6c06d49835d560914c2","player.css":"sha256:861924ad61c83b806d9461274f68dc6a5c9dba605205d25c8e8443ae23e74d6d","credits.txt":"sha256:bddccf53c42964b940a91a499ba2aad0ce1e9b6ea9a6b5f456e0792faeb5227f","save-compatibility.json":"sha256:3b783b1cc6c5cdf2ede2ff0219598eca3d1f19344dd58787f8f40c884ea6f8a3","offline.js":"sha256:3c03eb9e70e4cb515c889f1671dcdb00401c20a98a81b97b3861fb6afd4ca7e0","app-icon.svg":"sha256:e6c8ab87ad0b0192c7707b02b0c0128f3b99c63965b3378469a02978002bd533","manifest.webmanifest":"sha256:55434928d4bf2a0979ebeb53e8430fea4bc21409f69a8e35d012204d18f9502d","offline.css":"sha256:446a996d2421f5267c00c6e38e0b430ea703c570370f0beb7783bf2553333348"};
const version = "sha256:3bc764f58d5eb35d8557a1e1d6758863bfd73d3b1c0505b1c779ffae4a0ebe7b";

const prefix = 'world-offline:' + encodeURIComponent(self.registration.scope) + ':';
const cacheName = prefix + version;
const entries = Object.entries(inventory).map(([path, digest]) => [new URL(path, self.registration.scope).href, digest]);
const urls = new Set(entries.map(([url]) => url));
async function fill() {
  const cache = await caches.open(cacheName);
  for (const [url, digest] of entries) {
    if (await cache.match(url)) continue;
    const response = await fetch(url, { cache: 'no-store' });
    if (!response.ok) throw new Error('missing file');
    const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', await response.clone().arrayBuffer()))).map(x => x.toString(16).padStart(2, '0')).join('');
    if ('sha256:' + hash !== digest) throw new Error('incomplete deployment');
    await cache.put(url, response);
  }
}
async function complete() {
  const cache = await caches.open(cacheName);
  return (await Promise.all(entries.map(async ([url]) => Boolean(await cache.match(url))))).every(Boolean);
}
self.addEventListener('install', event => event.waitUntil(fill().catch(async error => { await caches.delete(cacheName); throw error; })));
self.addEventListener('activate', event => event.waitUntil((async () => {
  for (const key of await caches.keys()) if (key.startsWith(prefix) && key !== cacheName) await caches.delete(key);
  await self.clients.claim();
})()));
self.addEventListener('message', event => {
  if (!['STATUS', 'CACHE'].includes(event.data?.type)) return;
  event.waitUntil((async () => {
    try { if (event.data.type === 'CACHE') await fill(); event.ports[0]?.postMessage({ ready: await complete(), version }); }
    catch { event.ports[0]?.postMessage({ ready: false, version }); }
  })());
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url); url.search = ''; url.hash = '';
  if (url.href === self.registration.scope) url.pathname += 'index.html';
  if (!urls.has(url.href)) return;
  event.respondWith((async () => {
    const response = await (await caches.open(cacheName)).match(url.href);
    if (!response) return fetch(event.request);
    const range = event.request.headers.get('range');
    if (!range) return response;
    const match = /^bytes=(\d*)-(\d*)$/.exec(range);
    if (!match || (!match[1] && !match[2])) return response;
    const bytes = await response.arrayBuffer();
    const start = match[1] ? Number(match[1]) : Math.max(0, bytes.byteLength - Number(match[2]));
    const end = match[1] && match[2] ? Math.min(Number(match[2]), bytes.byteLength - 1) : bytes.byteLength - 1;
    if (start > end) return new Response(null, { status: 416, headers: { 'Content-Range': 'bytes */' + bytes.byteLength } });
    const headers = new Headers(response.headers); headers.delete('Content-Encoding');
    headers.set('Content-Range', 'bytes ' + start + '-' + end + '/' + bytes.byteLength);
    headers.set('Content-Length', String(end - start + 1)); headers.set('Accept-Ranges', 'bytes');
    return new Response(bytes.slice(start, end + 1), { status: 206, headers });
  })());
});