(() => {
  const status = document.getElementById('offline-status');
  const summary = document.getElementById('offline-summary');
  const action = document.getElementById('offline-action');
  const cancel = document.getElementById('offline-cancel');
  const install = document.getElementById('offline-install');
  let registration, promptEvent, operation, cancelledWorker, lastFailure, epoch = 0;
  const say = (text, label) => { status.textContent = text; summary.textContent = label; };
  const finish = () => {
    const restoreFocus = document.activeElement === cancel || (operation?.restoreFocus && document.activeElement === document.body);
    epoch++; operation = undefined; lastFailure = undefined; cancel.hidden = true; cancel.disabled = false; cancel.textContent = '取消下载'; action.disabled = false;
    if (restoreFocus) action.focus();
  };
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault(); promptEvent = event; install.hidden = false;
  });
  install.onclick = async () => {
    if (!promptEvent) return;
    await promptEvent.prompt(); await promptEvent.userChoice;
    promptEvent = undefined; install.hidden = true;
  };
  if (location.protocol === 'world-game:') {
    say('桌面播放器已使用本地游戏文件，无需下载网站离线内容。', '本地文件'); action.hidden = true; return;
  }
  if (location.protocol === 'file:') {
    say('本地目录可直接试玩；网站离线与安装需发布到 HTTPS 站点。', '本地文件'); action.hidden = true; return;
  }
  if (!isSecureContext || !('serviceWorker' in navigator)) {
    say('当前浏览器或网址不支持网站离线，可继续在线玩；请使用 HTTPS 或下载完整目录包。', '当前环境不支持'); action.hidden = true; return;
  }
  const request = (worker, type, requestId) => new Promise((resolve, reject) => {
    const channel = new MessageChannel();
    const timer = setTimeout(() => { channel.port1.close(); reject(new Error('timeout')); }, type === 'CACHE' ? 300000 : 10000);
    channel.port1.onmessage = event => { clearTimeout(timer); channel.port1.close(); resolve(event.data); };
    try { worker.postMessage({ type, requestId }, [channel.port2]); }
    catch (error) { clearTimeout(timer); channel.port1.close(); reject(error); }
  });
  const start = (worker, mode, id = 'install') => {
    epoch++; cancelledWorker = undefined; lastFailure = undefined; operation = { worker, mode, id };
    action.disabled = true; cancel.hidden = false; cancel.disabled = false; cancel.textContent = '取消下载';
    say('正在下载并核对离线文件；可以返回故事继续游玩。', '下载中'); return operation;
  };
  const cancelled = mode => {
    finish();
    say(mode === 'update' ? '已取消新版下载，原有离线内容和故事进度保留。需要时可重试更新。' : '已取消离线下载，故事进度不会删除。联网时仍可继续玩，需要离线时请重试下载。', '已取消');
    action.textContent = mode === 'update' ? '重试更新' : '重试离线下载';
  };
  const waiting = () => {
    if (!registration?.waiting) return false;
    finish();
    say('新版已下载，当前故事仍使用原版，不会自动打断。只有作者核对过的兼容版本才能继续旧档；未经核对的更新请保留原版入口。关闭所有游戏窗口后重新打开会使用新版。', '新版等待重开');
    action.textContent = '检查更新'; return true;
  };
  const ready = async () => {
    if (waiting()) return;
    if (!registration?.active) return;
    const pending = epoch;
    try {
      const result = await request(registration.active, 'STATUS');
      if (epoch !== pending) return;
      if (waiting()) return;
      finish();
      if (result.ready) { say('离线内容已就绪（文件已缓存）。请在当前浏览器断网重开并核对画面、声音和存读档；浏览器清理站点数据后需重新下载。', '文件已缓存'); action.textContent = '检查更新'; }
      else { say('离线内容不完整，请联网重新下载；在线游玩仍可继续。', '需要重新下载'); action.textContent = '重试离线下载'; }
    } catch { if (epoch !== pending) return; finish(); say('暂时无法确认离线内容，请联网重试。', '状态未确认'); action.textContent = '重试离线下载'; }
  };
  const failed = (cacheRepair, detail) => {
    const updating = Boolean(registration?.active) && !cacheRepair;
    const pending = operation ?? lastFailure; finish(); lastFailure = pending;
    const file = detail?.path ? ' 未完成文件：' + String(detail.path).slice(0, 256) + '。' : '';
    const reason = detail?.reason === 'integrity' ? '文件与本版清单不一致，请联系发布者检查上传是否完整。' : detail?.reason === 'http' ? '下载返回 HTTP ' + detail.httpStatus + '；请检查网络，或联系发布者检查该文件。' : '请检查网络和可用空间后重试。';
    say((updating ? '新版下载或更新失败，原有离线内容保留，当前故事不会切换。' : '离线下载失败，在线游戏仍可继续。') + file + reason, updating ? '更新失败' : '下载失败');
    action.textContent = updating ? '重试更新' : '重试离线下载';
  };
  navigator.serviceWorker.addEventListener('message', event => {
    const detail = event.data;
    const pending = operation ?? (detail?.phase === 'failed' ? lastFailure : undefined);
    if (!pending || event.source !== pending.worker || detail?.type !== 'WORLD_OFFLINE_PROGRESS' || detail.requestId !== pending.id || cancelledWorker === event.source) return;
    if (detail.phase === 'cancelled') { cancelledWorker = event.source; cancelled(operation.mode); }
    else if (detail.phase === 'failed') failed(pending.mode === 'repair', detail);
    else if (detail.phase === 'progress' && Number.isSafeInteger(detail.completed) && Number.isSafeInteger(detail.total) && detail.total > 0 && detail.completed >= 0 && detail.completed <= detail.total) {
      say('正在下载并核对离线内容：' + detail.completed + ' / ' + detail.total + ' 个文件。' + (detail.path ? ' 当前：' + String(detail.path).slice(0, 256) + '。' : '') + '可以返回故事继续游玩。', '下载中 ' + detail.completed + '/' + detail.total);
    }
  });
  const observe = worker => {
    if (!worker) return;
    start(worker, registration?.active ? 'update' : 'download');
    const changed = () => {
      if (cancelledWorker === worker) return;
      if (worker.state === 'activated') void ready();
      if (worker.state === 'installed') { if (!waiting()) say('离线下载完成，正在准备…', '正在准备'); }
      if (worker.state === 'redundant' && operation?.worker === worker) failed(false);
    };
    worker.addEventListener('statechange', changed); changed();
  };
  const watch = () => {
    registration.addEventListener('updatefound', () => observe(registration.installing));
    if (registration.installing) observe(registration.installing); else void ready();
  };
  cancel.onclick = async () => {
    const pending = operation; if (!pending) return;
    pending.restoreFocus = document.activeElement === cancel;
    cancelledWorker = pending.worker; cancel.disabled = true; cancel.textContent = '正在取消…';
    try {
      const result = await request(pending.worker, 'CANCEL', pending.id);
      if (operation !== pending) return;
      if (result.cancelled) cancelled(pending.mode);
      else { cancelledWorker = undefined; await ready(); }
    } catch {
      if (operation !== pending) return;
      cancelledWorker = undefined; cancel.disabled = false; cancel.textContent = '取消下载';
      say('暂时无法确认取消结果；可以继续游玩，或再次取消下载。', '取消未确认');
    }
  };
  action.onclick = async () => {
    const cacheRepair = action.textContent === '重试离线下载' && Boolean(registration?.active);
    action.disabled = true;
    let pending;
    try {
      if (!registration || (!registration.active && !registration.waiting && !registration.installing)) { registration = await navigator.serviceWorker.register('./sw.js', { scope: './', updateViaCache: 'none' }); watch(); }
      else if (cacheRepair) {
        pending = start(registration.active, 'repair', crypto.randomUUID());
        const result = await request(registration.active, 'CACHE', pending.id);
        if (operation !== pending || cancelledWorker === pending.worker) return;
        if (result.busy) { finish(); say('另一窗口正在下载本游戏的离线内容，可以继续游玩，稍后再核对。', '另一窗口下载中'); action.textContent = '重试离线下载'; return; }
        if (!result.ready) throw new Error('cache failed');
        await ready();
      } else {
        const pendingEpoch = epoch;
        await registration.update();
        if (!registration.installing && epoch === pendingEpoch) await ready();
      }
    } catch { if (pending ? operation === pending && cancelledWorker !== pending.worker : !cancelledWorker) failed(cacheRepair); }
  };
  navigator.serviceWorker.getRegistration('./').then(value => {
    if (value && value.scope === new URL('./', location.href).href) { registration = value; watch(); }
  }).catch(() => { say('无法读取离线状态，请重试。', '状态未确认'); });
})();