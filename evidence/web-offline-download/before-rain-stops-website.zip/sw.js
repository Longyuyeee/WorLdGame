const inventory = {"optimization-report.json":"sha256:1484027ca12c6463ec39f346cd85bb75b9d1b2ae50f6d1dead3f50516a54ddf6","media/a1e6e500aa1ca5d4b0dcdca821070f1b17f617a14227f76a83eb0257e128847b.png":"sha256:a1e6e500aa1ca5d4b0dcdca821070f1b17f617a14227f76a83eb0257e128847b","media/558c25c6e369f18b98ff550165c38a06fc96f1ba0fba89ab69c3dc45f08bf94e.png":"sha256:558c25c6e369f18b98ff550165c38a06fc96f1ba0fba89ab69c3dc45f08bf94e","media/cd749f04403e3b4c8483350b77e79fb01bf9166de3f65e9d701583d43afead75.png":"sha256:cd749f04403e3b4c8483350b77e79fb01bf9166de3f65e9d701583d43afead75","media/1ed954eeb7d22cd6176cb702dbc78977684c6a47261a8b36e152654d2700968a.png":"sha256:1ed954eeb7d22cd6176cb702dbc78977684c6a47261a8b36e152654d2700968a","media/598b41535295814f1e98a4388d8df83012897402090b83d988e5e2c6b583b57f.png":"sha256:598b41535295814f1e98a4388d8df83012897402090b83d988e5e2c6b583b57f","media/9ded1d5e951474c53f36f92fa7dc5ab6fcf575ebc3d6fb648a2759c5f9015698.png":"sha256:9ded1d5e951474c53f36f92fa7dc5ab6fcf575ebc3d6fb648a2759c5f9015698","media/d8721a9d412e6589161ceffc2ada4f65e9c20ff7402319569b4a86623ab00c96.png":"sha256:d8721a9d412e6589161ceffc2ada4f65e9c20ff7402319569b4a86623ab00c96","media/6ef4b958c86328d5515b034a7060e5081430fcdc279536ceeaac43f15ce7f83b.png":"sha256:6ef4b958c86328d5515b034a7060e5081430fcdc279536ceeaac43f15ce7f83b","media/d69d2e28ca0d7d547c27f32cbd49703ebc40ddf36b0224f56001f7d2a73bd16a.wav":"sha256:d69d2e28ca0d7d547c27f32cbd49703ebc40ddf36b0224f56001f7d2a73bd16a","media/7b0aeee0aef6219584fef7833b6960ecb316bffa3b565ab13f847151068ba0bd.png":"sha256:7b0aeee0aef6219584fef7833b6960ecb316bffa3b565ab13f847151068ba0bd","media/fbbc665d5ebb4e5dad123383d1077f3d968a620b7e36cce46795c08669605c98.wav":"sha256:fbbc665d5ebb4e5dad123383d1077f3d968a620b7e36cce46795c08669605c98","media/78c4a9d21f19861265c4ce8c8e3b56f4a8bdb0777515ec93a9e53facbb17b863.wav":"sha256:78c4a9d21f19861265c4ce8c8e3b56f4a8bdb0777515ec93a9e53facbb17b863","media/49e0d7f4aedf5242a8c5001d3875ec3cae7836d5c73e57415db7f5fdaf627807.png":"sha256:49e0d7f4aedf5242a8c5001d3875ec3cae7836d5c73e57415db7f5fdaf627807","media/26be1da92d18729069c0fda981697a09631fbe7525d4517af5f3633824bf13c0.wav":"sha256:26be1da92d18729069c0fda981697a09631fbe7525d4517af5f3633824bf13c0","media/342b2b082636ff9d0e8fff71a0ad7f53dfc5bb3fb6125927371b0828cf417197.wav":"sha256:342b2b082636ff9d0e8fff71a0ad7f53dfc5bb3fb6125927371b0828cf417197","media/9851880463e1d27bb758947fd998c834d942817f5c589fdd1b3ef31f870add27.wav":"sha256:9851880463e1d27bb758947fd998c834d942817f5c589fdd1b3ef31f870add27","media/d2cd20b0b73ee05ee5ae19a1d6f0af29956e492144a3f708747cdc84bb6cd1d8.wav":"sha256:d2cd20b0b73ee05ee5ae19a1d6f0af29956e492144a3f708747cdc84bb6cd1d8","media/eeff44bae98f46d3fefaf1b8d9e3f27ee08ac635043e8d660e759f57946d8057.wav":"sha256:eeff44bae98f46d3fefaf1b8d9e3f27ee08ac635043e8d660e759f57946d8057","media/0e68ac781943cf48422d833c6eb6550f66ee4fb31901f12f492e3ca8c079695a.wav":"sha256:0e68ac781943cf48422d833c6eb6550f66ee4fb31901f12f492e3ca8c079695a","media/cc0bd25e03762753601ed2464aff8cb0fadd99db43610a7eaebb752a7acef028.wav":"sha256:cc0bd25e03762753601ed2464aff8cb0fadd99db43610a7eaebb752a7acef028","media/b7b78ec4e28133260db750e20de3e4c56bda60e6e65f73b58b09412e75e76d4c.wav":"sha256:b7b78ec4e28133260db750e20de3e4c56bda60e6e65f73b58b09412e75e76d4c","media/f90e09e4c2dadc8c6d255c137cd4ce3bc5b40d8a7331e9467c813075a809786a.wav":"sha256:f90e09e4c2dadc8c6d255c137cd4ce3bc5b40d8a7331e9467c813075a809786a","media/9a2a3bce8a89205a0ae6ac1cd22620dedae77bd519db5ec5c90b2302b55db47b.png":"sha256:9a2a3bce8a89205a0ae6ac1cd22620dedae77bd519db5ec5c90b2302b55db47b","media/db56676dcd83122d0f0442173693870abb9f6df05d732d510f9915ccea963fc6.png":"sha256:db56676dcd83122d0f0442173693870abb9f6df05d732d510f9915ccea963fc6","media/5ab4b3cf1b83bf897d386238f1fad4e87f36b6eea3d940e0c3d4101204404e37.png":"sha256:5ab4b3cf1b83bf897d386238f1fad4e87f36b6eea3d940e0c3d4101204404e37","media/02ab310670cd897e865ebb590e66094b188c305ee61959e8b4160e6f30ba2e9a.png":"sha256:02ab310670cd897e865ebb590e66094b188c305ee61959e8b4160e6f30ba2e9a","index.html":"sha256:9608199c38e5620a8834531712705c78c88fb529b0aec62320699189fa2a8dc7","player.js":"sha256:7949b6fcf013927e8ba4b9f2332d4894a1b7d84b42841062a940cca0fb75e4c1","player.css":"sha256:c5a667da8e9083753ecd58f02e43b016cd0ad67a85dee62cd8eded63ff0436e1","save-compatibility.json":"sha256:3b783b1cc6c5cdf2ede2ff0219598eca3d1f19344dd58787f8f40c884ea6f8a3","offline.js":"sha256:e80f8bfca52050786517ecd24b445d94706eccb3512bd9a06341a76f04da92cf","app-icon.svg":"sha256:e6c8ab87ad0b0192c7707b02b0c0128f3b99c63965b3378469a02978002bd533","manifest.webmanifest":"sha256:a1fa144a6eddc72268a7d7d9d642dbb4de09c9fb003f4cd3f4e81a9b1421d048","offline.css":"sha256:29de969e2f4e2b8ba3a5faa96fbd255f619ef87314407b902572580d425d8cc3"};
const version = "sha256:ddef5bf57fe45d595cf04457b4b28c489bc9620548585fcb79cf2d1136f90fe9";

const prefix = 'world-offline:' + encodeURIComponent(self.registration.scope) + ':';
const cacheName = prefix + version;
const entries = Object.entries(inventory).map(([path, digest]) => [new URL(path, self.registration.scope).href, digest]);
const urls = new Set(entries.map(([url]) => url));
let activeTask;
async function report(task, phase, detail = {}) {
  const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
  for (const client of clients) if (client.url.startsWith(self.registration.scope)) {
    try { client.postMessage({ type: 'WORLD_OFFLINE_PROGRESS', requestId: task.id, phase, completed: task.completed, total: entries.length, path: task.path, ...detail }); } catch { /* A closed page must not fail the download. */ }
  }
}
function fill(requestId = 'install') {
  if (activeTask) return activeTask.promise;
  const task = { id: requestId, controller: new AbortController(), completed: 0, path: '' };
  activeTask = task;
  task.promise = (async () => {
    const signal = task.controller.signal;
    try {
      const cache = await caches.open(cacheName);
      for (const [url, digest] of entries) {
        task.path = url.slice(self.registration.scope.length);
        if (signal.aborted) throw new DOMException('cancelled', 'AbortError');
        await report(task, 'progress');
        if (!await cache.match(url)) {
          const response = await fetch(url, { cache: 'no-store', signal });
          if (!response.ok) throw Object.assign(new Error('missing file'), { reason: 'http', httpStatus: response.status });
          const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', await response.clone().arrayBuffer()))).map(x => x.toString(16).padStart(2, '0')).join('');
          if ('sha256:' + hash !== digest) throw Object.assign(new Error('incomplete deployment'), { reason: 'integrity' });
          if (signal.aborted) throw new DOMException('cancelled', 'AbortError');
          await cache.put(url, response);
        }
        task.completed++;
      }
      task.path = ''; await report(task, 'progress');
    } catch (error) {
      await report(task, signal.aborted ? 'cancelled' : 'failed', { reason: error.reason, httpStatus: error.httpStatus });
      throw error;
    } finally { if (activeTask === task) activeTask = undefined; }
  })();
  return task.promise;
}
async function complete() {
  if (!(await caches.keys()).includes(cacheName)) return false;
  const cache = await caches.open(cacheName);
  return (await Promise.all(entries.map(async ([url]) => Boolean(await cache.match(url))))).every(Boolean);
}
self.addEventListener('install', event => event.waitUntil(fill().catch(async error => { await caches.delete(cacheName); throw error; })));
self.addEventListener('activate', event => event.waitUntil((async () => {
  for (const key of await caches.keys()) if (key.startsWith(prefix) && key !== cacheName) await caches.delete(key);
  await self.clients.claim();
})()));
self.addEventListener('message', event => {
  if (!['STATUS', 'CACHE', 'CANCEL'].includes(event.data?.type)) return;
  event.waitUntil((async () => {
    try {
      if (event.data.type === 'CANCEL') {
        const task = activeTask, owned = Boolean(task && task.id === event.data.requestId);
        if (owned) { task.controller.abort(); await task.promise.catch(() => {}); }
        event.ports[0]?.postMessage({ cancelled: owned, ready: owned && task.id === 'install' ? false : await complete(), version }); return;
      }
      if (event.data.type === 'CACHE') {
        if (activeTask && activeTask.id !== event.data.requestId) { event.ports[0]?.postMessage({ busy: true, version }); return; }
        await fill(event.data.requestId);
      }
      event.ports[0]?.postMessage({ ready: await complete(), version });
    }
    catch { event.ports[0]?.postMessage({ ready: false, version }); }
  })());
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url); url.search = ''; url.hash = '';
  if (url.href === self.registration.scope) url.pathname += 'index.html';
  if (!urls.has(url.href)) return;
  event.respondWith((async () => {
    const response = await (await caches.open(cacheName)).match(url.href);
    if (!response) return fetch(event.request);
    const range = event.request.headers.get('range');
    if (!range) return response;
    const match = /^bytes=(\d*)-(\d*)$/.exec(range);
    if (!match || (!match[1] && !match[2])) return response;
    const bytes = await response.arrayBuffer();
    const start = match[1] ? Number(match[1]) : Math.max(0, bytes.byteLength - Number(match[2]));
    const end = match[1] && match[2] ? Math.min(Number(match[2]), bytes.byteLength - 1) : bytes.byteLength - 1;
    if (start > end) return new Response(null, { status: 416, headers: { 'Content-Range': 'bytes */' + bytes.byteLength } });
    const headers = new Headers(response.headers); headers.delete('Content-Encoding');
    headers.set('Content-Range', 'bytes ' + start + '-' + end + '/' + bytes.byteLength);
    headers.set('Content-Length', String(end - start + 1)); headers.set('Accept-Ranges', 'bytes');
    return new Response(bytes.slice(start, end + 1), { status: 206, headers });
  })());
});