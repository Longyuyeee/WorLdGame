const inventory = {"optimization-report.json":"sha256:6a3571b6cebe50176d68e406ab1f7e8878d315759ecfd3c676bf0298a0e130e8","media/558c25c6e369f18b98ff550165c38a06fc96f1ba0fba89ab69c3dc45f08bf94e.png":"sha256:558c25c6e369f18b98ff550165c38a06fc96f1ba0fba89ab69c3dc45f08bf94e","media/1ed954eeb7d22cd6176cb702dbc78977684c6a47261a8b36e152654d2700968a.png":"sha256:1ed954eeb7d22cd6176cb702dbc78977684c6a47261a8b36e152654d2700968a","media/598b41535295814f1e98a4388d8df83012897402090b83d988e5e2c6b583b57f.png":"sha256:598b41535295814f1e98a4388d8df83012897402090b83d988e5e2c6b583b57f","media/9ded1d5e951474c53f36f92fa7dc5ab6fcf575ebc3d6fb648a2759c5f9015698.png":"sha256:9ded1d5e951474c53f36f92fa7dc5ab6fcf575ebc3d6fb648a2759c5f9015698","media/6ef4b958c86328d5515b034a7060e5081430fcdc279536ceeaac43f15ce7f83b.png":"sha256:6ef4b958c86328d5515b034a7060e5081430fcdc279536ceeaac43f15ce7f83b","media/d69d2e28ca0d7d547c27f32cbd49703ebc40ddf36b0224f56001f7d2a73bd16a.wav":"sha256:d69d2e28ca0d7d547c27f32cbd49703ebc40ddf36b0224f56001f7d2a73bd16a","media/7b0aeee0aef6219584fef7833b6960ecb316bffa3b565ab13f847151068ba0bd.png":"sha256:7b0aeee0aef6219584fef7833b6960ecb316bffa3b565ab13f847151068ba0bd","media/fbbc665d5ebb4e5dad123383d1077f3d968a620b7e36cce46795c08669605c98.wav":"sha256:fbbc665d5ebb4e5dad123383d1077f3d968a620b7e36cce46795c08669605c98","media/78c4a9d21f19861265c4ce8c8e3b56f4a8bdb0777515ec93a9e53facbb17b863.wav":"sha256:78c4a9d21f19861265c4ce8c8e3b56f4a8bdb0777515ec93a9e53facbb17b863","media/26be1da92d18729069c0fda981697a09631fbe7525d4517af5f3633824bf13c0.wav":"sha256:26be1da92d18729069c0fda981697a09631fbe7525d4517af5f3633824bf13c0","media/342b2b082636ff9d0e8fff71a0ad7f53dfc5bb3fb6125927371b0828cf417197.wav":"sha256:342b2b082636ff9d0e8fff71a0ad7f53dfc5bb3fb6125927371b0828cf417197","media/9851880463e1d27bb758947fd998c834d942817f5c589fdd1b3ef31f870add27.wav":"sha256:9851880463e1d27bb758947fd998c834d942817f5c589fdd1b3ef31f870add27","media/eccfe5a280ecf38ef861570ed7239cb4046caa94f53ad62709e387f990ed9221.wav":"sha256:eccfe5a280ecf38ef861570ed7239cb4046caa94f53ad62709e387f990ed9221","media/eeff44bae98f46d3fefaf1b8d9e3f27ee08ac635043e8d660e759f57946d8057.wav":"sha256:eeff44bae98f46d3fefaf1b8d9e3f27ee08ac635043e8d660e759f57946d8057","media/0e68ac781943cf48422d833c6eb6550f66ee4fb31901f12f492e3ca8c079695a.wav":"sha256:0e68ac781943cf48422d833c6eb6550f66ee4fb31901f12f492e3ca8c079695a","media/cc0bd25e03762753601ed2464aff8cb0fadd99db43610a7eaebb752a7acef028.wav":"sha256:cc0bd25e03762753601ed2464aff8cb0fadd99db43610a7eaebb752a7acef028","media/b7b78ec4e28133260db750e20de3e4c56bda60e6e65f73b58b09412e75e76d4c.wav":"sha256:b7b78ec4e28133260db750e20de3e4c56bda60e6e65f73b58b09412e75e76d4c","media/f90e09e4c2dadc8c6d255c137cd4ce3bc5b40d8a7331e9467c813075a809786a.wav":"sha256:f90e09e4c2dadc8c6d255c137cd4ce3bc5b40d8a7331e9467c813075a809786a","media/9a2a3bce8a89205a0ae6ac1cd22620dedae77bd519db5ec5c90b2302b55db47b.png":"sha256:9a2a3bce8a89205a0ae6ac1cd22620dedae77bd519db5ec5c90b2302b55db47b","media/db56676dcd83122d0f0442173693870abb9f6df05d732d510f9915ccea963fc6.png":"sha256:db56676dcd83122d0f0442173693870abb9f6df05d732d510f9915ccea963fc6","media/5ab4b3cf1b83bf897d386238f1fad4e87f36b6eea3d940e0c3d4101204404e37.png":"sha256:5ab4b3cf1b83bf897d386238f1fad4e87f36b6eea3d940e0c3d4101204404e37","media/02ab310670cd897e865ebb590e66094b188c305ee61959e8b4160e6f30ba2e9a.png":"sha256:02ab310670cd897e865ebb590e66094b188c305ee61959e8b4160e6f30ba2e9a","index.html":"sha256:b7b403bfd6da5f4dca35530b4c7e5319daa3e901af547bc43138a59e2986b93b","player.js":"sha256:6178fb510fea6a6adaa926b8002b32ff87ba8601486cb3dc5d3388b642e283a9","player.css":"sha256:c1c0c3e75c9f48a958bf3b6e9f79cabdc99b3fc1570e59ad493354dd6d9a7782","offline.js":"sha256:d6124801e0082dd376969824e74d6ee6a27a6a19b63a3cbb9f6319f9f1d88fc8","app-icon.svg":"sha256:e6c8ab87ad0b0192c7707b02b0c0128f3b99c63965b3378469a02978002bd533","manifest.webmanifest":"sha256:a1fa144a6eddc72268a7d7d9d642dbb4de09c9fb003f4cd3f4e81a9b1421d048","offline.css":"sha256:446a996d2421f5267c00c6e38e0b430ea703c570370f0beb7783bf2553333348"};
const version = "sha256:ab3f073619df018775842bfcc2324a6cd29bc7031c14ca4472a21a841f53956f";

const prefix = 'world-offline:' + encodeURIComponent(self.registration.scope) + ':';
const cacheName = prefix + version;
const entries = Object.entries(inventory).map(([path, digest]) => [new URL(path, self.registration.scope).href, digest]);
const urls = new Set(entries.map(([url]) => url));
async function fill() {
  const cache = await caches.open(cacheName);
  for (const [url, digest] of entries) {
    if (await cache.match(url)) continue;
    const response = await fetch(url, { cache: 'no-store' });
    if (!response.ok) throw new Error('missing file');
    const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', await response.clone().arrayBuffer()))).map(x => x.toString(16).padStart(2, '0')).join('');
    if ('sha256:' + hash !== digest) throw new Error('incomplete deployment');
    await cache.put(url, response);
  }
}
async function complete() {
  const cache = await caches.open(cacheName);
  return (await Promise.all(entries.map(async ([url]) => Boolean(await cache.match(url))))).every(Boolean);
}
self.addEventListener('install', event => event.waitUntil(fill().catch(async error => { await caches.delete(cacheName); throw error; })));
self.addEventListener('activate', event => event.waitUntil((async () => {
  for (const key of await caches.keys()) if (key.startsWith(prefix) && key !== cacheName) await caches.delete(key);
  await self.clients.claim();
})()));
self.addEventListener('message', event => {
  if (!['STATUS', 'CACHE'].includes(event.data?.type)) return;
  event.waitUntil((async () => {
    try { if (event.data.type === 'CACHE') await fill(); event.ports[0]?.postMessage({ ready: await complete(), version }); }
    catch { event.ports[0]?.postMessage({ ready: false, version }); }
  })());
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url); url.search = ''; url.hash = '';
  if (url.href === self.registration.scope) url.pathname += 'index.html';
  if (!urls.has(url.href)) return;
  event.respondWith((async () => {
    const response = await (await caches.open(cacheName)).match(url.href);
    if (!response) return fetch(event.request);
    const range = event.request.headers.get('range');
    if (!range) return response;
    const match = /^bytes=(\d*)-(\d*)$/.exec(range);
    if (!match || (!match[1] && !match[2])) return response;
    const bytes = await response.arrayBuffer();
    const start = match[1] ? Number(match[1]) : Math.max(0, bytes.byteLength - Number(match[2]));
    const end = match[1] && match[2] ? Math.min(Number(match[2]), bytes.byteLength - 1) : bytes.byteLength - 1;
    if (start > end) return new Response(null, { status: 416, headers: { 'Content-Range': 'bytes */' + bytes.byteLength } });
    const headers = new Headers(response.headers); headers.delete('Content-Encoding');
    headers.set('Content-Range', 'bytes ' + start + '-' + end + '/' + bytes.byteLength);
    headers.set('Content-Length', String(end - start + 1)); headers.set('Accept-Ranges', 'bytes');
    return new Response(bytes.slice(start, end + 1), { status: 206, headers });
  })());
});