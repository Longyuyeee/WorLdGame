const inventory = {"optimization-report.json":"sha256:ece23f6041d72bd061c0fa0eade8dd58cf0bc5d71d9216dd0d7ff295b4599d70","media/0b3ad4fe2fb65b34c700b66b9680f2f4115c416eaa4331d99a43e3cd6827f4fe.png":"sha256:0b3ad4fe2fb65b34c700b66b9680f2f4115c416eaa4331d99a43e3cd6827f4fe","media/123d997e075762d5e4653fab71f1285500f3da3f1526da6e0cf3093d23a897b5.png":"sha256:123d997e075762d5e4653fab71f1285500f3da3f1526da6e0cf3093d23a897b5","media/13ba9456d14ec66d659e3ed9043f776d3c754b4a9942a23bed9e708a51add258.png":"sha256:13ba9456d14ec66d659e3ed9043f776d3c754b4a9942a23bed9e708a51add258","media/21abc625ea998f2f2210527a1b0f6a25f79995ec394d56e8baceabba0c54e036.png":"sha256:21abc625ea998f2f2210527a1b0f6a25f79995ec394d56e8baceabba0c54e036","media/308cb21fb4309a7183a3e17ae9f395afc21864d4cd9aaa598bc81ae934fbadb4.png":"sha256:308cb21fb4309a7183a3e17ae9f395afc21864d4cd9aaa598bc81ae934fbadb4","media/31d1486303238ebbbf9eaf4f1b16e8c4531aa5df36dc1f73bfb3677dae642cbf.png":"sha256:31d1486303238ebbbf9eaf4f1b16e8c4531aa5df36dc1f73bfb3677dae642cbf","media/3931423e6faaf7095ec4651dfa89f922704801e04fc31326abb0f8b619501d51.png":"sha256:3931423e6faaf7095ec4651dfa89f922704801e04fc31326abb0f8b619501d51","media/3aa340fed5111be19f08e6debdec9e62b9df4efb6346aa77747f298b9a58a3b5.png":"sha256:3aa340fed5111be19f08e6debdec9e62b9df4efb6346aa77747f298b9a58a3b5","media/609706b272e28ba0c1472e84df4322aa62b5338accd1138623aeef09d45854f8.png":"sha256:609706b272e28ba0c1472e84df4322aa62b5338accd1138623aeef09d45854f8","media/6be8c20a718815b9dc2313f8fab559c841130fa7604876ebb1b8e691d36b5d9b.png":"sha256:6be8c20a718815b9dc2313f8fab559c841130fa7604876ebb1b8e691d36b5d9b","media/74b25588f810ceaed62c83f496bb3298c49c93d9ba1aa81175a9a925fa39977d.png":"sha256:74b25588f810ceaed62c83f496bb3298c49c93d9ba1aa81175a9a925fa39977d","media/7b0aeee0aef6219584fef7833b6960ecb316bffa3b565ab13f847151068ba0bd.png":"sha256:7b0aeee0aef6219584fef7833b6960ecb316bffa3b565ab13f847151068ba0bd","media/98047083a6a3c82c7d33277d59ea687c16b7cde56bedf198d899db652eff9f9b.woff2":"sha256:98047083a6a3c82c7d33277d59ea687c16b7cde56bedf198d899db652eff9f9b","media/c721a1731fef1cec5a8507bf6f54d1fc4d42a85a4762c4ffe5b15d1f0e594c76.png":"sha256:c721a1731fef1cec5a8507bf6f54d1fc4d42a85a4762c4ffe5b15d1f0e594c76","media/d4e88f0f28f4a814824138c8ee1e328c5a95e016bc41cc85675780bd15004921.png":"sha256:d4e88f0f28f4a814824138c8ee1e328c5a95e016bc41cc85675780bd15004921","media/dc0a6a068beb46bc45f5a10862a41768cc905a6ae0581644c016a748b9e90200.png":"sha256:dc0a6a068beb46bc45f5a10862a41768cc905a6ae0581644c016a748b9e90200","media/e4928f48c8e60e8408d6c65746c008bbd938a19b1b5f6d3d42354d40725decd3.png":"sha256:e4928f48c8e60e8408d6c65746c008bbd938a19b1b5f6d3d42354d40725decd3","media/f069365936e08e91a372d1620f59f570e0d8595f99dc934b34cf8f35a1c871ee.png":"sha256:f069365936e08e91a372d1620f59f570e0d8595f99dc934b34cf8f35a1c871ee","media/f3f56b2367eddf21575c7936e4ee21356734f221bb594397d9a32b971153cc66.png":"sha256:f3f56b2367eddf21575c7936e4ee21356734f221bb594397d9a32b971153cc66","index.html":"sha256:0e616f852168eb265afbb3f65ff848c76a8caae98e85bebbcf952e1099f3494c","player.js":"sha256:40ed18cf1d1ebc00d6a37e51264f06e0f1b0886c2d6e83f7a1578eea781bfe35","player.css":"sha256:67e9ba3a32a50dc30c4f0bc3b50093fac00608157ec9763468fea6b47ef0d623","credits.txt":"sha256:35e7f3c0490a760ac48ba08ec875a0486cd6f275f8682b85566327727ec5f496","save-compatibility.json":"sha256:3b783b1cc6c5cdf2ede2ff0219598eca3d1f19344dd58787f8f40c884ea6f8a3","offline.js":"sha256:3c03eb9e70e4cb515c889f1671dcdb00401c20a98a81b97b3861fb6afd4ca7e0","app-icon.svg":"sha256:e6c8ab87ad0b0192c7707b02b0c0128f3b99c63965b3378469a02978002bd533","manifest.webmanifest":"sha256:52e02758f2d8257efaf818b60240cbeb34466076185988664e8d927b319fc031","offline.css":"sha256:446a996d2421f5267c00c6e38e0b430ea703c570370f0beb7783bf2553333348"};
const version = "sha256:b5b2e08475ee6201f100ee89c1744dc432d0ae0caa9f26f9b6dcfc9f2300f2be";

const prefix = 'world-offline:' + encodeURIComponent(self.registration.scope) + ':';
const cacheName = prefix + version;
const entries = Object.entries(inventory).map(([path, digest]) => [new URL(path, self.registration.scope).href, digest]);
const urls = new Set(entries.map(([url]) => url));
async function fill() {
  const cache = await caches.open(cacheName);
  for (const [url, digest] of entries) {
    if (await cache.match(url)) continue;
    const response = await fetch(url, { cache: 'no-store' });
    if (!response.ok) throw new Error('missing file');
    const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', await response.clone().arrayBuffer()))).map(x => x.toString(16).padStart(2, '0')).join('');
    if ('sha256:' + hash !== digest) throw new Error('incomplete deployment');
    await cache.put(url, response);
  }
}
async function complete() {
  const cache = await caches.open(cacheName);
  return (await Promise.all(entries.map(async ([url]) => Boolean(await cache.match(url))))).every(Boolean);
}
self.addEventListener('install', event => event.waitUntil(fill().catch(async error => { await caches.delete(cacheName); throw error; })));
self.addEventListener('activate', event => event.waitUntil((async () => {
  for (const key of await caches.keys()) if (key.startsWith(prefix) && key !== cacheName) await caches.delete(key);
  await self.clients.claim();
})()));
self.addEventListener('message', event => {
  if (!['STATUS', 'CACHE'].includes(event.data?.type)) return;
  event.waitUntil((async () => {
    try { if (event.data.type === 'CACHE') await fill(); event.ports[0]?.postMessage({ ready: await complete(), version }); }
    catch { event.ports[0]?.postMessage({ ready: false, version }); }
  })());
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url); url.search = ''; url.hash = '';
  if (url.href === self.registration.scope) url.pathname += 'index.html';
  if (!urls.has(url.href)) return;
  event.respondWith((async () => {
    const response = await (await caches.open(cacheName)).match(url.href);
    if (!response) return fetch(event.request);
    const range = event.request.headers.get('range');
    if (!range) return response;
    const match = /^bytes=(\d*)-(\d*)$/.exec(range);
    if (!match || (!match[1] && !match[2])) return response;
    const bytes = await response.arrayBuffer();
    const start = match[1] ? Number(match[1]) : Math.max(0, bytes.byteLength - Number(match[2]));
    const end = match[1] && match[2] ? Math.min(Number(match[2]), bytes.byteLength - 1) : bytes.byteLength - 1;
    if (start > end) return new Response(null, { status: 416, headers: { 'Content-Range': 'bytes */' + bytes.byteLength } });
    const headers = new Headers(response.headers); headers.delete('Content-Encoding');
    headers.set('Content-Range', 'bytes ' + start + '-' + end + '/' + bytes.byteLength);
    headers.set('Content-Length', String(end - start + 1)); headers.set('Accept-Ranges', 'bytes');
    return new Response(bytes.slice(start, end + 1), { status: 206, headers });
  })());
});