@echo off
chcp 65001 >nul
where node >nul 2>nul
if errorlevel 1 (
  echo 请先安装 Node.js 22 或更高版本：https://nodejs.org/
  echo 安装后重新双击 start-preview.cmd，无需 npm install。
  pause
  exit /b 1
)
node "%~dp0preview.mjs" %*
if errorlevel 1 pause
