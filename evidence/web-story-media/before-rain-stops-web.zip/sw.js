const inventory = {"optimization-report.json":"sha256:c0db425dd94ad3ee8f20e6e0129d561f8a9497aa4b2528be1df0f2f5b323c997","media/558c25c6e369f18b98ff550165c38a06fc96f1ba0fba89ab69c3dc45f08bf94e.png":"sha256:558c25c6e369f18b98ff550165c38a06fc96f1ba0fba89ab69c3dc45f08bf94e","media/9ded1d5e951474c53f36f92fa7dc5ab6fcf575ebc3d6fb648a2759c5f9015698.png":"sha256:9ded1d5e951474c53f36f92fa7dc5ab6fcf575ebc3d6fb648a2759c5f9015698","media/d69d2e28ca0d7d547c27f32cbd49703ebc40ddf36b0224f56001f7d2a73bd16a.wav":"sha256:d69d2e28ca0d7d547c27f32cbd49703ebc40ddf36b0224f56001f7d2a73bd16a","media/b4a5813a792ea2c60f622af71f35ecb2a597cafb038842d16c57ae32be05dd69.png":"sha256:b4a5813a792ea2c60f622af71f35ecb2a597cafb038842d16c57ae32be05dd69","media/fbbc665d5ebb4e5dad123383d1077f3d968a620b7e36cce46795c08669605c98.wav":"sha256:fbbc665d5ebb4e5dad123383d1077f3d968a620b7e36cce46795c08669605c98","media/78c4a9d21f19861265c4ce8c8e3b56f4a8bdb0777515ec93a9e53facbb17b863.wav":"sha256:78c4a9d21f19861265c4ce8c8e3b56f4a8bdb0777515ec93a9e53facbb17b863","media/db56676dcd83122d0f0442173693870abb9f6df05d732d510f9915ccea963fc6.png":"sha256:db56676dcd83122d0f0442173693870abb9f6df05d732d510f9915ccea963fc6","index.html":"sha256:ad21f73483e076d45443e2d69b5198acbc12125d7fa7bcbc44361d8c97ee2c80","player.js":"sha256:198f45ab1896c3db2e300bcc09f8c5030d480f52d523b1e68be06452544b3c1b","player.css":"sha256:41ecf3226ad8ded51be8a7b2ed417bf1b0c080b36db0a1b80d111498a0b51d71","offline.js":"sha256:33e65336e675cb3ce20a69f1df09b2aedbb3c39c02deb91f490b91aa97a7cc49","app-icon.svg":"sha256:e6c8ab87ad0b0192c7707b02b0c0128f3b99c63965b3378469a02978002bd533","manifest.webmanifest":"sha256:70e6e6ca0be8a2d9991a50bcbc2a06cf83258a62bc7b2a29a7a04882442d5c36","offline.css":"sha256:446a996d2421f5267c00c6e38e0b430ea703c570370f0beb7783bf2553333348"};
const version = "sha256:e83a2c729dcdbe6cedfee03fffd487e88ca76bd8becc7cc9264d31dbc86054ef";

const prefix = 'world-offline:' + encodeURIComponent(self.registration.scope) + ':';
const cacheName = prefix + version;
const entries = Object.entries(inventory).map(([path, digest]) => [new URL(path, self.registration.scope).href, digest]);
const urls = new Set(entries.map(([url]) => url));
async function fill() {
  const cache = await caches.open(cacheName);
  for (const [url, digest] of entries) {
    if (await cache.match(url)) continue;
    const response = await fetch(url, { cache: 'no-store' });
    if (!response.ok) throw new Error('missing file');
    const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', await response.clone().arrayBuffer()))).map(x => x.toString(16).padStart(2, '0')).join('');
    if ('sha256:' + hash !== digest) throw new Error('incomplete deployment');
    await cache.put(url, response);
  }
}
async function complete() {
  const cache = await caches.open(cacheName);
  return (await Promise.all(entries.map(async ([url]) => Boolean(await cache.match(url))))).every(Boolean);
}
self.addEventListener('install', event => event.waitUntil(fill().catch(async error => { await caches.delete(cacheName); throw error; })));
self.addEventListener('activate', event => event.waitUntil((async () => {
  for (const key of await caches.keys()) if (key.startsWith(prefix) && key !== cacheName) await caches.delete(key);
  await self.clients.claim();
})()));
self.addEventListener('message', event => {
  if (!['STATUS', 'CACHE'].includes(event.data?.type)) return;
  event.waitUntil((async () => {
    try { if (event.data.type === 'CACHE') await fill(); event.ports[0]?.postMessage({ ready: await complete(), version }); }
    catch { event.ports[0]?.postMessage({ ready: false, version }); }
  })());
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url); url.search = ''; url.hash = '';
  if (url.href === self.registration.scope) url.pathname += 'index.html';
  if (!urls.has(url.href)) return;
  event.respondWith((async () => {
    const response = await (await caches.open(cacheName)).match(url.href);
    if (!response) return fetch(event.request);
    const range = event.request.headers.get('range');
    if (!range) return response;
    const match = /^bytes=(\d*)-(\d*)$/.exec(range);
    if (!match || (!match[1] && !match[2])) return response;
    const bytes = await response.arrayBuffer();
    const start = match[1] ? Number(match[1]) : Math.max(0, bytes.byteLength - Number(match[2]));
    const end = match[1] && match[2] ? Math.min(Number(match[2]), bytes.byteLength - 1) : bytes.byteLength - 1;
    if (start > end) return new Response(null, { status: 416, headers: { 'Content-Range': 'bytes */' + bytes.byteLength } });
    const headers = new Headers(response.headers); headers.delete('Content-Encoding');
    headers.set('Content-Range', 'bytes ' + start + '-' + end + '/' + bytes.byteLength);
    headers.set('Content-Length', String(end - start + 1)); headers.set('Accept-Ranges', 'bytes');
    return new Response(bytes.slice(start, end + 1), { status: 206, headers });
  })());
});