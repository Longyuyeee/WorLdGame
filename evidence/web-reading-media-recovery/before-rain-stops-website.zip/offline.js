(() => {
  const status = document.getElementById('offline-status');
  const summary = document.getElementById('offline-summary');
  const action = document.getElementById('offline-action');
  const cancel = document.getElementById('offline-cancel');
  const install = document.getElementById('offline-install');
  const tools = document.getElementById('world-publication-tools');
  const plan = document.getElementById('offline-update-plan');
  const acknowledge = document.getElementById('offline-update-ack');
  const confirm = document.getElementById('offline-update-confirm');
  const latestLink = document.getElementById('offline-open-latest');
  const storageOpen = document.getElementById('offline-storage-open'), storagePanel = document.getElementById('offline-storage');
  const storageStatus = document.getElementById('offline-storage-status'), storageList = document.getElementById('offline-storage-list');
  const storageConfirm = document.getElementById('offline-storage-confirm'), storageAck = document.getElementById('offline-storage-ack'), storageDelete = document.getElementById('offline-storage-delete');
  let storageEpoch = 0, storageBusy = false, selectedRelease, storageTrigger;
  const ownRelease = tools.dataset.worldRelease, ownVersion = tools.dataset.publicationVersion;
  let latestInfo, planBusy = false;
  let registration, promptEvent, operation, cancelledWorker, lastFailure, epoch = 0;
  const say = (text, label) => { status.textContent = text; summary.textContent = label; };
  const finish = () => {
    const restoreFocus = document.activeElement === cancel || (operation?.restoreFocus && document.activeElement === document.body);
    epoch++; operation = undefined; lastFailure = undefined; cancel.hidden = true; cancel.disabled = false; cancel.textContent = '取消下载'; action.disabled = false;
    if (restoreFocus) action.focus();
  };
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault(); promptEvent = event; install.hidden = false;
  });
  install.onclick = async () => {
    if (!promptEvent) return;
    await promptEvent.prompt(); await promptEvent.userChoice;
    promptEvent = undefined; install.hidden = true;
  };
  if (location.protocol === 'world-game:') {
    say('桌面播放器已使用本地游戏文件，无需下载网站离线内容。', '本地文件'); action.hidden = true; return;
  }
  if (location.protocol === 'file:') {
    say('本地目录可直接试玩；网站离线与安装需发布到 HTTPS 站点。', '本地文件'); action.hidden = true; return;
  }
  if (!isSecureContext || !('serviceWorker' in navigator)) {
    say('当前浏览器或网址不支持网站离线，可继续在线玩；请使用 HTTPS 或下载完整目录包。', '当前环境不支持'); action.hidden = true; return;
  }
  if (document.getElementById('player-root')?.dataset.startupState === 'release-missing') { action.hidden = true; return; }
  const releaseUrl = release => { const url = new URL(location.pathname, location.href); url.searchParams.set('world-release', release); return url.href; };
  document.getElementById('offline-keep-entry').onclick = () => {
    const entry = document.getElementById('offline-current-entry'); entry.value = releaseUrl(ownRelease); entry.hidden = false; entry.focus(); entry.select();
  };
  const openBackup = () => {
    if (tools.dispatchEvent(new Event('world-open-save-backup', { cancelable: true }))) say('暂时无法打开备份，请从存读档的“备份”页导出进度；当前故事保持不变。', '请先备份');
  };
  document.getElementById('offline-backup').onclick = openBackup;
  document.getElementById('offline-storage-backup').onclick = openBackup;
  const updatePlan = () => {
    const newer = latestInfo && latestInfo.releaseId !== ownRelease;
    confirm.hidden = false;
    confirm.disabled = !acknowledge.checked || Boolean(operation) || planBusy;
    confirm.textContent = registration?.waiting ? '启用已下载新版（本版仍保留）' : newer ? '再次检查更新' : '确认检查并下载';
    latestLink.hidden = !newer || Boolean(registration?.waiting) || !acknowledge.checked;
    if (newer) latestLink.href = releaseUrl(latestInfo.releaseId);
    document.getElementById('offline-version-note').textContent = newer ? '当前窗口：' + ownVersion + '；本机可用新版：' + latestInfo.publicationVersion + '。版本号相同也可能是运行文件更新；旧档仍需实际核验。' : '当前窗口：' + ownVersion + '。先保留需要的进度和本版入口，再检查更新。';
  };
  const setLatest = info => {
    if (!info || !/^sha256:[a-f0-9]{64}$/.test(info.releaseId) || typeof info.publicationVersion !== 'string') return;
    if (latestInfo?.releaseId !== info.releaseId) acknowledge.checked = false;
    latestInfo = info; updatePlan();
  };
  const showPlan = () => { plan.hidden = false; updatePlan(); };
  acknowledge.onchange = updatePlan;
  document.getElementById('offline-update-later').onclick = () => { plan.hidden = true; action.focus(); };
  const request = (worker, type, requestId, detail = {}) => new Promise((resolve, reject) => {
    const channel = new MessageChannel();
    const timer = setTimeout(() => { channel.port1.close(); reject(new Error('timeout')); }, type === 'CACHE' ? 300000 : 10000);
    channel.port1.onmessage = event => { clearTimeout(timer); channel.port1.close(); resolve(event.data); };
    try { worker.postMessage({ ...detail, type, requestId }, [channel.port2]); }
    catch (error) { clearTimeout(timer); channel.port1.close(); reject(error); }
  });
  const storageReasons = { current: '当前窗口正在使用，不能清理。', default: '本机默认版本，保留供启动与离线使用。', used: '其他游戏窗口正在使用；请先关闭对应窗口，再刷新列表。', unknownWindow: '存在无法确认版本的游戏窗口；请先关闭其他游戏窗口，再刷新。', updating: '正在下载、修复或等待启用新版，请完成后再清理。', unknown: '版本信息缺失或损坏，暂不清理，避免误删。', busy: '缓存正在读取或清理，请稍后刷新重试。', missing: '这个版本已不在缓存中，请刷新列表。', invalid: '清理请求无效，未执行清理。' };
  const sizeText = bytes => Number.isSafeInteger(bytes) && bytes >= 0 ? '约 ' + (bytes / 1048576).toFixed(1) + ' MiB' : '大小未能读取';
  const clearSelection = () => { selectedRelease = undefined; storageConfirm.hidden = true; storageAck.checked = false; storageDelete.disabled = true; document.getElementById('offline-storage-cancel').disabled = false; };
  const drawStorage = result => {
    storageList.replaceChildren();
    for (const item of result.releases) {
      const row = document.createElement('article'), title = document.createElement('h4'), info = document.createElement('p'), reason = document.createElement('p'), remove = document.createElement('button');
      const label = (item.publicationVersion ? '版本 ' + String(item.publicationVersion).slice(0, 64) : '版本信息未知') + ' · 构建 ' + item.releaseId.slice(-8);
      row.setAttribute('aria-label', label); title.textContent = label;
      info.textContent = item.fileCount + ' 个缓存文件 · 内容' + sizeText(item.byteLength) + (item.complete ? ' · 文件齐全' : ' · 文件不完整或信息缺失');
      reason.textContent = storageReasons[item.reason] ?? '未在使用，可以选择清理。';
      remove.type = 'button'; remove.textContent = '清理这个版本'; remove.disabled = Boolean(item.reason);
      remove.onclick = () => {
        if (storageBusy) return;
        clearSelection(); selectedRelease = item.releaseId; storageTrigger = remove; storageConfirm.hidden = false;
        document.getElementById('offline-storage-selected').textContent = '准备清理：' + label + '，缓存文件内容' + sizeText(item.byteLength) + '。';
        storageAck.focus();
      };
      row.append(title, info, reason, remove); storageList.append(row);
    }
    return result.releases.length ? '本游戏 ' + result.releases.length + ' 份缓存，文件内容合计' + sizeText(result.byteLength) + '。' : '本游戏尚无可识别的版本缓存。';
  };
  const loadStorage = async note => {
    if (storageBusy) return;
    const current = ++storageEpoch, worker = registration?.active;
    const report = text => { storageStatus.textContent = (note ? note + ' ' : '') + text; };
    clearSelection(); storageBusy = true; document.getElementById('offline-storage-refresh').disabled = true; storageList.replaceChildren(); storageStatus.textContent = '正在核对本游戏的缓存文件与使用窗口…';
    try {
      if (!worker) { report('本游戏离线组件尚未就绪，请先下载离线内容。'); return; }
      const result = await request(worker, 'STORAGE');
      if (current !== storageEpoch) return;
      if (registration.active !== worker) { report('离线组件已切换，请刷新缓存列表。'); return; }
      if (result.busy) { report('另一窗口正在核对或清理缓存，请稍后刷新。'); return; }
      if (result.schemaVersion !== 1 || !Array.isArray(result.releases)) throw new Error('unsupported');
      report(drawStorage(result));
    } catch { if (current === storageEpoch) report(note ? '暂时无法刷新缓存列表，请稍后再核对。' : '暂时无法读取缓存列表，离线组件可能较旧。请完成更新后重试；未执行清理。'); }
    finally { if (current === storageEpoch) { storageBusy = false; document.getElementById('offline-storage-refresh').disabled = false; } }
  };
  storageOpen.hidden = false;
  storageOpen.onclick = () => { storagePanel.hidden = false; void loadStorage(); };
  document.getElementById('offline-storage-refresh').onclick = () => { void loadStorage(); };
  document.getElementById('offline-storage-close').onclick = () => { storagePanel.hidden = true; clearSelection(); storageOpen.focus(); };
  document.getElementById('offline-storage-cancel').onclick = () => { if (storageBusy) return; clearSelection(); storageTrigger?.focus(); };
  storageAck.onchange = () => { storageDelete.disabled = !storageAck.checked || storageBusy; };
  storageDelete.onclick = async () => {
    const releaseId = selectedRelease, worker = registration?.active;
    if (!releaseId || !storageAck.checked || storageBusy || !worker) return;
    const startedHere = storageConfirm.contains(document.activeElement);
    storageBusy = true; storageDelete.disabled = true; document.getElementById('offline-storage-cancel').disabled = true; document.getElementById('offline-storage-refresh').disabled = true; storageStatus.textContent = '正在重新核对使用窗口并清理所选版本；提交后不能撤销…';
    let restoreFocus = false;
    try {
      const result = await request(worker, 'DELETE_RELEASE', undefined, { releaseId, confirmed: true });
      restoreFocus = startedHere && (storageConfirm.contains(document.activeElement) || document.activeElement === document.body);
      storageBusy = false;
      await loadStorage(result.deleted ? '所选版本缓存已移除；存档未删除，原版入口不再可用。实际回收空间由浏览器决定。' : storageReasons[result.reason] ?? '未能确认清理结果，请刷新列表核对。');
    } catch { restoreFocus = startedHere && (storageConfirm.contains(document.activeElement) || document.activeElement === document.body); storageBusy = false; clearSelection(); document.getElementById('offline-storage-refresh').disabled = false; storageStatus.textContent = '未能确认清理结果，请刷新列表核对；不要重复提交。'; }
    if (restoreFocus && !storagePanel.hidden) document.getElementById('offline-storage-refresh').focus();
  };
  const start = (worker, mode, id = 'install') => {
    epoch++; cancelledWorker = undefined; lastFailure = undefined; operation = { worker, mode, id };
    action.disabled = true; cancel.hidden = false; cancel.disabled = false; cancel.textContent = '取消下载';
    say('正在下载并核对离线文件；可以返回故事继续游玩。', '下载中'); return operation;
  };
  const cancelled = mode => {
    finish();
    say(mode === 'update' ? '已取消新版下载，原有离线内容和故事进度保留。需要时可重试更新。' : '已取消离线下载，故事进度不会删除。联网时仍可继续玩，需要离线时请重试下载。', '已取消');
    action.textContent = mode === 'update' ? '重试更新' : '重试离线下载';
  };
  const waiting = () => {
    if (!registration?.waiting) return false;
    finish();
    say('新版已下载。当前窗口继续本版，重开本版入口也不会自动换剧情。先备份并保留本版入口，再选择启用新版；本机缓存并非永久备份。', '新版等待选择');
    action.textContent = '查看已下载新版'; showPlan();
    const worker = registration.waiting;
    void request(worker, 'INFO').then(info => { if (registration.waiting === worker || registration.active === worker) setLatest(info); }).catch(() => {});
    return true;
  };
  const ready = async () => {
    if (waiting()) return;
    if (!registration?.active) return;
    const pending = ++epoch, worker = registration.active;
    try {
      const result = await request(worker, 'STATUS');
      if (epoch !== pending || registration.active !== worker) return;
      if (waiting()) return;
      finish();
      setLatest(result.latest);
      if (result.ready) { say(result.retained ? '本版离线内容仍保留，本机另有新版。可先备份并保留本版入口，再选择在新窗口打开新版；当前故事不会切换。' : '离线内容已就绪（文件已缓存）。请在当前浏览器断网重开并核对画面、声音和存读档；浏览器清理站点数据后需重新下载。', '文件已缓存'); action.textContent = result.retained ? '查看版本与备份' : '检查更新'; }
      else if (result.retained) { say('本版缓存不完整，不能用新版文件补齐。请保留存档备份，使用作者提供的原版完整游戏；也可查看新版，但旧档可能不兼容。', '旧版文件缺失'); action.textContent = '查看版本与备份'; }
      else { say('离线内容不完整，请联网重新下载；在线游玩仍可继续。', '需要重新下载'); action.textContent = '重试离线下载'; }
    } catch { if (epoch !== pending || registration.active !== worker) return; finish(); say('暂时无法确认离线内容，请联网重试。', '状态未确认'); action.textContent = '重试离线下载'; }
  };
  const failed = (cacheRepair, detail) => {
    const updating = Boolean(registration?.active) && !cacheRepair;
    const pending = operation ?? lastFailure; finish(); lastFailure = pending;
    const file = detail?.path ? ' 未完成文件：' + String(detail.path).slice(0, 256) + '。' : '';
    const reason = detail?.reason === 'integrity' ? '文件与本版清单不一致，请联系发布者检查上传是否完整。' : detail?.reason === 'http' ? '下载返回 HTTP ' + detail.httpStatus + '；请检查网络，或联系发布者检查该文件。' : '请检查网络和可用空间后重试。';
    say((updating ? '新版下载或更新失败，原有离线内容保留，当前故事不会切换。' : '离线下载失败，在线游戏仍可继续。') + file + reason, updating ? '更新失败' : '下载失败');
    action.textContent = updating ? '重试更新' : '重试离线下载';
  };
  navigator.serviceWorker.addEventListener('message', event => {
    const detail = event.data;
    const pending = operation ?? (detail?.phase === 'failed' ? lastFailure : undefined);
    if (!pending || event.source !== pending.worker || detail?.type !== 'WORLD_OFFLINE_PROGRESS' || detail.requestId !== pending.id || cancelledWorker === event.source) return;
    if (detail.phase === 'cancelled') { cancelledWorker = event.source; cancelled(operation.mode); }
    else if (detail.phase === 'failed') failed(pending.mode === 'repair', detail);
    else if (detail.phase === 'progress' && Number.isSafeInteger(detail.completed) && Number.isSafeInteger(detail.total) && detail.total > 0 && detail.completed >= 0 && detail.completed <= detail.total) {
      say('正在下载并核对离线内容：' + detail.completed + ' / ' + detail.total + ' 个文件。' + (detail.path ? ' 当前：' + String(detail.path).slice(0, 256) + '。' : '') + '可以返回故事继续游玩。', '下载中 ' + detail.completed + '/' + detail.total);
    }
  });
  const observe = worker => {
    if (!worker) return;
    start(worker, registration?.active ? 'update' : 'download');
    const changed = () => {
      if (cancelledWorker === worker) return;
      if (worker.state === 'activated') void ready();
      if (worker.state === 'installed') { if (!waiting()) say('离线下载完成，正在准备…', '正在准备'); }
      if (worker.state === 'redundant' && operation?.worker === worker) failed(false);
    };
    worker.addEventListener('statechange', changed); changed();
  };
  const watch = () => {
    registration.addEventListener('updatefound', () => observe(registration.installing));
    if (registration.installing) observe(registration.installing); else void ready();
  };
  cancel.onclick = async () => {
    const pending = operation; if (!pending) return;
    pending.restoreFocus = document.activeElement === cancel;
    cancelledWorker = pending.worker; cancel.disabled = true; cancel.textContent = '正在取消…';
    try {
      const result = await request(pending.worker, 'CANCEL', pending.id);
      if (operation !== pending) return;
      if (result.cancelled) cancelled(pending.mode);
      else { cancelledWorker = undefined; await ready(); }
    } catch {
      if (operation !== pending) return;
      cancelledWorker = undefined; cancel.disabled = false; cancel.textContent = '取消下载';
      say('暂时无法确认取消结果；可以继续游玩，或再次取消下载。', '取消未确认');
    }
  };
  const perform = async approved => {
    const cacheRepair = action.textContent === '重试离线下载' && Boolean(registration?.active);
    action.disabled = true;
    let pending;
    try {
      if (!registration || (!registration.active && !registration.waiting && !registration.installing)) { registration = await navigator.serviceWorker.register('./sw.js', { scope: './', updateViaCache: 'none' }); watch(); }
      else if (cacheRepair) {
        pending = start(registration.active, 'repair', crypto.randomUUID());
        const result = await request(registration.active, 'CACHE', pending.id);
        if (operation !== pending || cancelledWorker === pending.worker) return;
        if (result.busy) { finish(); say('另一窗口正在下载本游戏的离线内容，可以继续游玩，稍后再核对。', '另一窗口下载中'); action.textContent = '重试离线下载'; return; }
        if (!result.ready) throw new Error('cache failed');
        await ready();
      } else {
        if (!approved) { action.disabled = false; showPlan(); return; }
        if (registration.waiting) { await request(registration.waiting, 'ACTIVATE'); return; }
        const pendingEpoch = epoch, previousWorker = registration.active;
        await registration.update();
        if (!registration.installing && epoch === pendingEpoch) {
          await ready();
          if (!operation && !registration.waiting && registration.active === previousWorker) say('已检查更新，暂未发现新的可用版本。当前窗口继续本版，已缓存的其他版本仍可在下方选择。', '暂无新版');
        }
      }
    } catch { if (pending ? operation === pending && cancelledWorker !== pending.worker : !cancelledWorker) failed(cacheRepair); }
  };
  action.onclick = () => { void perform(false); };
  confirm.onclick = () => { if (!acknowledge.checked || planBusy) return; planBusy = true; confirm.disabled = true; void perform(true).finally(() => { planBusy = false; updatePlan(); }); };
  navigator.serviceWorker.addEventListener('controllerchange', () => { void ready(); });
  navigator.serviceWorker.getRegistration('./').then(value => {
    if (value && value.scope === new URL('./', location.href).href) { registration = value; watch(); }
  }).catch(() => { say('无法读取离线状态，请重试。', '状态未确认'); });
})();