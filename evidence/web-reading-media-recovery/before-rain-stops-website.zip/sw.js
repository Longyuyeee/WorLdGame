const inventory = {"optimization-report.json":"sha256:ce55440853db44cefd1b28f35b995f2bedc082deabd49ca13b0e91c87e4afb08","media/a1e6e500aa1ca5d4b0dcdca821070f1b17f617a14227f76a83eb0257e128847b.png":"sha256:a1e6e500aa1ca5d4b0dcdca821070f1b17f617a14227f76a83eb0257e128847b","media/558c25c6e369f18b98ff550165c38a06fc96f1ba0fba89ab69c3dc45f08bf94e.png":"sha256:558c25c6e369f18b98ff550165c38a06fc96f1ba0fba89ab69c3dc45f08bf94e","media/cd749f04403e3b4c8483350b77e79fb01bf9166de3f65e9d701583d43afead75.png":"sha256:cd749f04403e3b4c8483350b77e79fb01bf9166de3f65e9d701583d43afead75","media/1ed954eeb7d22cd6176cb702dbc78977684c6a47261a8b36e152654d2700968a.png":"sha256:1ed954eeb7d22cd6176cb702dbc78977684c6a47261a8b36e152654d2700968a","media/598b41535295814f1e98a4388d8df83012897402090b83d988e5e2c6b583b57f.png":"sha256:598b41535295814f1e98a4388d8df83012897402090b83d988e5e2c6b583b57f","media/9ded1d5e951474c53f36f92fa7dc5ab6fcf575ebc3d6fb648a2759c5f9015698.png":"sha256:9ded1d5e951474c53f36f92fa7dc5ab6fcf575ebc3d6fb648a2759c5f9015698","media/d8721a9d412e6589161ceffc2ada4f65e9c20ff7402319569b4a86623ab00c96.png":"sha256:d8721a9d412e6589161ceffc2ada4f65e9c20ff7402319569b4a86623ab00c96","media/6ef4b958c86328d5515b034a7060e5081430fcdc279536ceeaac43f15ce7f83b.png":"sha256:6ef4b958c86328d5515b034a7060e5081430fcdc279536ceeaac43f15ce7f83b","media/d69d2e28ca0d7d547c27f32cbd49703ebc40ddf36b0224f56001f7d2a73bd16a.wav":"sha256:d69d2e28ca0d7d547c27f32cbd49703ebc40ddf36b0224f56001f7d2a73bd16a","media/7b0aeee0aef6219584fef7833b6960ecb316bffa3b565ab13f847151068ba0bd.png":"sha256:7b0aeee0aef6219584fef7833b6960ecb316bffa3b565ab13f847151068ba0bd","media/fbbc665d5ebb4e5dad123383d1077f3d968a620b7e36cce46795c08669605c98.wav":"sha256:fbbc665d5ebb4e5dad123383d1077f3d968a620b7e36cce46795c08669605c98","media/78c4a9d21f19861265c4ce8c8e3b56f4a8bdb0777515ec93a9e53facbb17b863.wav":"sha256:78c4a9d21f19861265c4ce8c8e3b56f4a8bdb0777515ec93a9e53facbb17b863","media/49e0d7f4aedf5242a8c5001d3875ec3cae7836d5c73e57415db7f5fdaf627807.png":"sha256:49e0d7f4aedf5242a8c5001d3875ec3cae7836d5c73e57415db7f5fdaf627807","media/26be1da92d18729069c0fda981697a09631fbe7525d4517af5f3633824bf13c0.wav":"sha256:26be1da92d18729069c0fda981697a09631fbe7525d4517af5f3633824bf13c0","media/342b2b082636ff9d0e8fff71a0ad7f53dfc5bb3fb6125927371b0828cf417197.wav":"sha256:342b2b082636ff9d0e8fff71a0ad7f53dfc5bb3fb6125927371b0828cf417197","media/9851880463e1d27bb758947fd998c834d942817f5c589fdd1b3ef31f870add27.wav":"sha256:9851880463e1d27bb758947fd998c834d942817f5c589fdd1b3ef31f870add27","media/d2cd20b0b73ee05ee5ae19a1d6f0af29956e492144a3f708747cdc84bb6cd1d8.wav":"sha256:d2cd20b0b73ee05ee5ae19a1d6f0af29956e492144a3f708747cdc84bb6cd1d8","media/eeff44bae98f46d3fefaf1b8d9e3f27ee08ac635043e8d660e759f57946d8057.wav":"sha256:eeff44bae98f46d3fefaf1b8d9e3f27ee08ac635043e8d660e759f57946d8057","media/0e68ac781943cf48422d833c6eb6550f66ee4fb31901f12f492e3ca8c079695a.wav":"sha256:0e68ac781943cf48422d833c6eb6550f66ee4fb31901f12f492e3ca8c079695a","media/cc0bd25e03762753601ed2464aff8cb0fadd99db43610a7eaebb752a7acef028.wav":"sha256:cc0bd25e03762753601ed2464aff8cb0fadd99db43610a7eaebb752a7acef028","media/b7b78ec4e28133260db750e20de3e4c56bda60e6e65f73b58b09412e75e76d4c.wav":"sha256:b7b78ec4e28133260db750e20de3e4c56bda60e6e65f73b58b09412e75e76d4c","media/f90e09e4c2dadc8c6d255c137cd4ce3bc5b40d8a7331e9467c813075a809786a.wav":"sha256:f90e09e4c2dadc8c6d255c137cd4ce3bc5b40d8a7331e9467c813075a809786a","media/9a2a3bce8a89205a0ae6ac1cd22620dedae77bd519db5ec5c90b2302b55db47b.png":"sha256:9a2a3bce8a89205a0ae6ac1cd22620dedae77bd519db5ec5c90b2302b55db47b","media/db56676dcd83122d0f0442173693870abb9f6df05d732d510f9915ccea963fc6.png":"sha256:db56676dcd83122d0f0442173693870abb9f6df05d732d510f9915ccea963fc6","media/5ab4b3cf1b83bf897d386238f1fad4e87f36b6eea3d940e0c3d4101204404e37.png":"sha256:5ab4b3cf1b83bf897d386238f1fad4e87f36b6eea3d940e0c3d4101204404e37","media/02ab310670cd897e865ebb590e66094b188c305ee61959e8b4160e6f30ba2e9a.png":"sha256:02ab310670cd897e865ebb590e66094b188c305ee61959e8b4160e6f30ba2e9a","index.html":"sha256:cf3ee2622ca66634af083097692a7564456670e6df6c1a89d894dad1c481bf97","player.js":"sha256:bebaf749ecc30488467484cd266f2f1fc39e2344cb8bcdbd773e66ee86c4f7c9","player.css":"sha256:617f13a0708fe56d9d0dcfb579f24372fed37ab4ec1ecfb97c748cfd7fb2d7ed","save-compatibility.json":"sha256:3b783b1cc6c5cdf2ede2ff0219598eca3d1f19344dd58787f8f40c884ea6f8a3","offline.js":"sha256:562ce3f0ccce2f1c75567d211e6e0e590f3048abe02bbea5670f0d49b6b74585","app-icon.svg":"sha256:e6c8ab87ad0b0192c7707b02b0c0128f3b99c63965b3378469a02978002bd533","manifest.webmanifest":"sha256:381f5c6371f1eac52974d6a3b43b525b3c52d29806c5c47a9a21f1e5596edae0","offline.css":"sha256:b379d49a054f1e9716aeb2fc49d877dfc9d5bf64904eaf47683a3522bcd84718"};
const version = "sha256:7820e0b77e1767bd3ef67b86263d012e0b43709c6c32a337a6601dbcae15cfc8";
const publicationVersion = "1.11.0";

const prefix = 'world-offline:' + encodeURIComponent(self.registration.scope) + ':';
const cacheName = prefix + version;
const entries = Object.entries(inventory).map(([path, digest]) => [new URL(path, self.registration.scope).href, digest]);
const metadataUrl = new URL('__world-release-info__', self.registration.scope).href;
const ownInfo = { schemaVersion: 1, releaseId: version, publicationVersion, inventory };
const releaseId = url => { const value = new URL(url).searchParams.get('world-release'); return value === null ? version : /^sha256:[a-f0-9]{64}$/.test(value) ? value : null; };
async function targetInfo(event) {
  const id = event.source?.url ? releaseId(event.source.url) : version;
  if (id === version) return { id, info: ownInfo };
  if (!id || !(await caches.keys()).includes(prefix + id)) return { id, info: null };
  try {
    const response = await (await caches.open(prefix + id)).match(metadataUrl), info = response && await response.json();
    return { id, info: info?.schemaVersion === 1 && info.releaseId === id && info.inventory && typeof info.publicationVersion === 'string' ? info : null };
  } catch { return { id, info: null }; }
}
let activeTask;
async function report(task, phase, detail = {}) {
  const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
  for (const client of clients) if (client.url.startsWith(self.registration.scope)) {
    try { client.postMessage({ type: 'WORLD_OFFLINE_PROGRESS', requestId: task.id, phase, completed: task.completed, total: entries.length, path: task.path, ...detail }); } catch { /* A closed page must not fail the download. */ }
  }
}
function fill(requestId = 'install') {
  if (activeTask) return activeTask.promise;
  const task = { id: requestId, controller: new AbortController(), completed: 0, path: '' };
  activeTask = task;
  task.promise = (async () => {
    const signal = task.controller.signal;
    try {
      const cache = await caches.open(cacheName);
      for (const [url, digest] of entries) {
        task.path = url.slice(self.registration.scope.length);
        if (signal.aborted) throw new DOMException('cancelled', 'AbortError');
        await report(task, 'progress');
        if (!await cache.match(url)) {
          const response = await fetch(url, { cache: 'no-store', signal });
          if (!response.ok) throw Object.assign(new Error('missing file'), { reason: 'http', httpStatus: response.status });
          const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', await response.clone().arrayBuffer()))).map(x => x.toString(16).padStart(2, '0')).join('');
          if ('sha256:' + hash !== digest) throw Object.assign(new Error('incomplete deployment'), { reason: 'integrity' });
          if (signal.aborted) throw new DOMException('cancelled', 'AbortError');
          await cache.put(url, response);
        }
        task.completed++;
      }
      await cache.put(metadataUrl, new Response(JSON.stringify(ownInfo), { headers: { 'Content-Type': 'application/json' } }));
      task.path = ''; await report(task, 'progress');
    } catch (error) {
      await report(task, signal.aborted ? 'cancelled' : 'failed', { reason: error.reason, httpStatus: error.httpStatus });
      throw error;
    } finally { if (activeTask === task) activeTask = undefined; }
  })();
  return task.promise;
}
async function complete(id = version, info = ownInfo) {
  if (!id || !info || !(await caches.keys()).includes(prefix + id)) return false;
  const cache = await caches.open(prefix + id);
  return (await Promise.all(Object.keys(info.inventory).map(async path => Boolean(await cache.match(new URL(path, self.registration.scope).href))))).every(Boolean);
}
const deleting = new Set(); let readers = 0, listings = 0;
async function cachedInfo(id) {
  if (!/^sha256:[a-f0-9]{64}$/.test(id)) return null;
  const target = await targetInfo({ source: { url: self.registration.scope + '?world-release=' + encodeURIComponent(id) } });
  const info = target.info, entries = info && typeof info.inventory === 'object' && !Array.isArray(info.inventory) ? Object.entries(info.inventory) : [];
  return entries.length && entries.every(([path, digest]) => path && !path.startsWith('/') && !/[\\?#]/.test(path) && !path.split('/').some(part => part === '.' || part === '..') && new URL(path, self.registration.scope).href.startsWith(self.registration.scope) && /^sha256:[a-f0-9]{64}$/.test(digest)) ? info : null;
}
async function protection(id, source) {
  if (id === releaseId(source.url)) return 'current';
  if (id === version) return 'default';
  if (activeTask || self.registration.installing || self.registration.waiting) return 'updating';
  if (readers) return 'busy';
  const windows = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
  for (const client of windows) {
    if (!client.url.startsWith(self.registration.scope)) continue;
    const selected = new URL(client.url).searchParams.get('world-release');
    if (!selected || !/^sha256:[a-f0-9]{64}$/.test(selected)) return 'unknownWindow';
    if (selected === id) return 'used';
  }
  return null;
}
async function storage(source) {
  if (deleting.size) return { busy: true };
  listings++;
  try {
  const releases = []; let byteLength = 0;
  for (const key of (await caches.keys()).sort()) {
    if (!key.startsWith(prefix)) continue;
    const id = key.slice(prefix.length); if (!/^sha256:[a-f0-9]{64}$/.test(id)) continue;
    const cache = await caches.open(key), info = await cachedInfo(id); let bytes = 0, fileCount = 0, known = true;
    for (const request of await cache.keys()) {
      if (request.url === metadataUrl) continue;
      fileCount++;
      try { const response = await cache.match(request); bytes += (await response.arrayBuffer()).byteLength; } catch { known = false; }
    }
    releases.push({ releaseId: id, publicationVersion: info?.publicationVersion, byteLength: known ? bytes : null, fileCount, complete: await complete(id, info), reason: await protection(id, source) ?? (info ? null : 'unknown') });
    byteLength = byteLength === null || !known ? null : byteLength + bytes;
  }
  return { schemaVersion: 1, releases, byteLength };
  } finally { listings--; }
}
async function deleteRelease(event) {
  const id = event.data.releaseId;
  if (event.data.confirmed !== true || typeof id !== 'string' || !/^sha256:[a-f0-9]{64}$/.test(id)) return { deleted: false, reason: 'invalid' };
  if (deleting.size || listings) return { deleted: false, reason: 'busy' };
  deleting.add(id);
  try {
    const active = self.registration.active;
    const reason = await protection(id, event.source);
    if (reason) return { deleted: false, reason };
    if (!(await caches.keys()).includes(prefix + id)) return { deleted: false, reason: 'missing' };
    if (!await cachedInfo(id)) return { deleted: false, reason: 'unknown' };
    // Recheck after metadata I/O: a tab or update may have appeared since selection.
    const changed = await protection(id, event.source);
    if (changed || self.registration.active !== active) return { deleted: false, reason: changed ?? 'updating' };
    return { deleted: await caches.delete(prefix + id) };
  } finally { deleting.delete(id); }
}
self.addEventListener('install', event => event.waitUntil(fill().catch(async error => { await caches.delete(cacheName); throw error; })));
self.addEventListener('activate', event => event.waitUntil((async () => {
  // Pinned pages and their saved links still need previous public game bytes.
  // Never delete an older game merely because another build activates.
  await self.clients.claim();
})()));
self.addEventListener('message', event => {
  if (!['STATUS', 'CACHE', 'CANCEL', 'INFO', 'ACTIVATE', 'STORAGE', 'DELETE_RELEASE'].includes(event.data?.type)) return;
  event.waitUntil((async () => {
    try {
      if (['STORAGE', 'DELETE_RELEASE'].includes(event.data.type)) {
        if (!event.source?.url?.startsWith(self.registration.scope)) { event.ports[0]?.postMessage({ deleted: false, reason: 'invalid' }); return; }
        event.ports[0]?.postMessage(event.data.type === 'STORAGE' ? await storage(event.source) : await deleteRelease(event)); return;
      }
      if (event.data.type === 'INFO') { event.ports[0]?.postMessage(ownInfo); return; }
      if (event.data.type === 'ACTIVATE') { await self.skipWaiting(); event.ports[0]?.postMessage({ activated: true }); return; }
      const target = await targetInfo(event);
      if (event.data.type === 'CANCEL') {
        const task = activeTask, owned = Boolean(task && task.id === event.data.requestId);
        if (owned) { task.controller.abort(); await task.promise.catch(() => {}); }
        event.ports[0]?.postMessage({ cancelled: owned, ready: owned && task.id === 'install' ? false : await complete(), version }); return;
      }
      if (event.data.type === 'CACHE') {
        if (target.id !== version) { event.ports[0]?.postMessage({ ready: false, retained: true, latest: ownInfo }); return; }
        if (activeTask && activeTask.id !== event.data.requestId) { event.ports[0]?.postMessage({ busy: true, version }); return; }
        await fill(event.data.requestId);
      }
      event.ports[0]?.postMessage({ ready: await complete(target.id, target.info), version: target.id, retained: target.id !== version, latest: ownInfo });
    }
    catch { event.ports[0]?.postMessage({ ready: false, version }); }
  })());
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (!url.href.startsWith(self.registration.scope)) return;
  const requested = url.searchParams.get('world-release'); url.search = ''; url.hash = '';
  if (url.href === self.registration.scope) url.pathname += 'index.html';
  if (url.href === metadataUrl) { event.respondWith(new Response('Not a public game file', { status: 404 })); return; }
  const blocked = new Set(deleting); readers++;
  event.respondWith((async () => {
    try {
    const client = event.clientId ? await self.clients.get(event.clientId) : null;
    const navigating = event.request.mode === 'navigate';
    const pinned = requested !== null || (!navigating && Boolean(client && new URL(client.url).searchParams.has('world-release')));
    const id = requested !== null ? releaseId(event.request.url) : navigating ? version : client ? releaseId(client.url) : version;
    const exists = id && (await caches.keys()).includes(prefix + id);
    const target = !blocked.has(id) && !deleting.has(id) && pinned && event.request.mode === 'navigate' ? await targetInfo({ source: { url: event.request.url } }) : null;
    const incomplete = target && !await complete(target.id, target.info);
    const response = exists && !incomplete && !blocked.has(id) && !deleting.has(id) ? await (await caches.open(prefix + id)).match(url.href) : null;
    if (!response) {
      if (!pinned) return fetch(event.request);
      if (event.request.mode === 'navigate') {
        const latest = self.registration.scope.replaceAll('&', '&amp;').replaceAll('"', '&quot;');
        return new Response('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>旧版入口不可用</title><main><h1>旧版离线内容不可用</h1><p role="alert">未替换为新版，也未改写存档。请保留备份，使用作者提供的原版游戏。清理缓存或换浏览器后，本版链接不能代替完整游戏文件。</p><a href="' + latest + '">查看当前线上版本（旧档可能不兼容）</a></main>', { status: 410, headers: { 'Content-Type': 'text/html; charset=utf-8' } });
      }
      return new Response('This retained version is missing a game file; refusing mixed-version fallback.', { status: 503 });
    }
    const range = event.request.headers.get('range');
    if (!range) return response;
    const match = /^bytes=(\d*)-(\d*)$/.exec(range);
    if (!match || (!match[1] && !match[2])) return response;
    const bytes = await response.arrayBuffer();
    const start = match[1] ? Number(match[1]) : Math.max(0, bytes.byteLength - Number(match[2]));
    const end = match[1] && match[2] ? Math.min(Number(match[2]), bytes.byteLength - 1) : bytes.byteLength - 1;
    if (start > end) return new Response(null, { status: 416, headers: { 'Content-Range': 'bytes */' + bytes.byteLength } });
    const headers = new Headers(response.headers); headers.delete('Content-Encoding');
    headers.set('Content-Range', 'bytes ' + start + '-' + end + '/' + bytes.byteLength);
    headers.set('Content-Length', String(end - start + 1)); headers.set('Accept-Ranges', 'bytes');
    return new Response(bytes.slice(start, end + 1), { status: 206, headers });
    } finally { readers--; }
  })());
});